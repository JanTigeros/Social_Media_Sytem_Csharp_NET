﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Social_Media
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Post> posts {  get; set; }
        ObservableCollection<string> tags = new ObservableCollection<string>();
        public Post currentPost;
        public ViewModel ViewModel { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            ViewModel = new ViewModel();
            this.DataContext = ViewModel;

            tags.Add("Prijatelj 1");
            tags.Add("Prijatelj 2");
            tags.Add("Prijatelj 3");
            LVFriends.ItemsSource = tags;
        }

        private void ListView_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            currentPost = (Post)LVPosts.SelectedItem;
            MessageBox.Show(currentPost.Content);

        }

        private void LVPosts_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentPost = (Post)LVPosts.SelectedItem;
            //ViewModel.SelectedContent = currentPost.Content;
            ViewModel.SelectedPost = currentPost;
        }

        private void ChangePost_OnClick(object sender, RoutedEventArgs e)
        {
            if (LVPosts.SelectedItem is Post p)
            {
                p.Content = TBContent.Text;
            }
        }

        private void MIIzhod_Click(object sender, RoutedEventArgs e)
        {
            Console.Write("Exit");
            System.Environment.Exit(1);
        }
    }
}
