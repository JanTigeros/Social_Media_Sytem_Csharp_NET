﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace Social_Media
{
    public class ViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Post> Posts { get; set; }
        private Post selectedPost;
        private int selectedIndex;


        public ICommand AddPostCommand { get; set; }
        public ICommand RemovePostCommand { get; set; }
        public ICommand EditPostCommand { get; set; }

        public ViewModel()
        {
            AddPostCommand = new Command(AddPost, CanAddPost);
            RemovePostCommand = new Command(RemovePost, CanAddPost);
            EditPostCommand = new Command(EditPost, CanAddPost);
            ObservableCollection<string> tags = new ObservableCollection<string>();
            tags.Add("Tag1");
            tags.Add("Tag2");

            Posts = new ObservableCollection<Post>
            {
                new Post(1, "What is Lorem Ipsum?", "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.", "https://i00.eu/img/605/1024x1024/2cj4v0gx/237680.jpg", tags),
                new Post(2, "Where does it come from?", "Contrary to popular belief, Lorem Ipsum is not simply random text.", "https://www.lifepng.com/wp-content/uploads/2020/09/Black-Cat-Sideview-png-hd.png", tags),
                new Post(3, "Why do we use it?", "The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.", "https://www.lifepng.com/wp-content/uploads/2020/09/Black-Cat-Scratching-png-hd.png", tags)
            };
        }

        public Post SelectedPost
        {
            get 
            {
                if (SelectedIndex > -1)
                {
                    return Posts[SelectedIndex];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                selectedPost = value;
                OnPropertyChanged(nameof(SelectedPost));
            }
        }

        public int SelectedIndex
        {
            get { return selectedIndex; }
            set
            {
                selectedIndex = value;
                OnPropertyChanged(nameof(SelectedIndex));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void AddPost(object obj)
        {
            Post post = new Post(4, "New Post", "New Post Conent", "https://www.lifepng.com/wp-content/uploads/2020/09/Black-Cat-Sideview-png-hd.png", new ObservableCollection<string> { "Friend1", "Friend2" });
            Posts.Add(post);
        }

        private bool CanAddPost(object obj)
        {
            return true;
        }

        private void RemovePost(object obj)
        {
            try
            {
                Posts.RemoveAt(SelectedIndex);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Izbran ni noben element!");
            }
            
                
        }

        private void EditPost(object obj)
        {
            try
            {
                SelectedPost.Content = "Edited Content";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Izbran ni noben element!");
            }
        }
    }
}
